
### Directory Description

Framework Folder <br>
├── [bin](https://github.com/DKAResearchCenter/DKAJSFramework/tree/master/src/Framework/bin)
Cli Program the base framework<br>
├── [module](https://github.com/DKAResearchCenter/DKAJSFramework/tree/master/src/Framework/Module)
the all module framework function <br>
└── [README.md](https://github.com/DKAResearchCenter/DKAJSFramework/blob/master/src/Framework/README.md)
You Here !
