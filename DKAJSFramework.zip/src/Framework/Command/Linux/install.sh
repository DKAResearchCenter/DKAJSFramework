#!/usr/bin/env bash

# shellcheck disable=SC2009
ps -ef | grep nginx
sudo apt-get update

