import PDF from "./PDF"

const Document = {
    PDF : PDF
};

export default Document;