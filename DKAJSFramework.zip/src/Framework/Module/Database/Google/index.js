import Firestore from "./Firestore";

const Google = {
    Firestore : Firestore
};

export default Google;
export { Google }