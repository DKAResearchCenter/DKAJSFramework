import DevicesManager from "./DevicesManager";

const Helper = {
    DeviceManager : DevicesManager
};

export default Helper;
export {Helper}