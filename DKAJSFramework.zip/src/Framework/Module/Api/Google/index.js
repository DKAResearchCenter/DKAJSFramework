import Firebase from "./Firebase";


const Google = {
    Firebase : Firebase
};


export default Google;
export { Firebase };
