class Database{

    constructor(app) {
        //console.log(app)
    }
}

export default Database;