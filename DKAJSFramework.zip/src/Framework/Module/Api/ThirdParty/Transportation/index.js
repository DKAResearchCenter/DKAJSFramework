import Gojek from "./Gojek";

const Transportation = {
    Gojek : Gojek
};


export default Transportation;