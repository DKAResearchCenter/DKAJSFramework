import SiCepat from "./SiCepat"

const Expedition = {
    SiCepat : SiCepat
};


export default Expedition;