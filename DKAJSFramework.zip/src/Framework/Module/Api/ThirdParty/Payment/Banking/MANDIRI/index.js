

class Mandiri {

}

export default Mandiri;