import MidTrans from "./MidTrans";

const Fintech = {
    MidTrans : MidTrans
};

export default Fintech;
export { MidTrans };

