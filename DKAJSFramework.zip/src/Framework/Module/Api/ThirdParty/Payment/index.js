import Banking from "./Banking";
import Fintech from "./Fintech";

const Payment = {
    Banking : Banking,
    Fintech : Fintech
};


export default Payment;
export { Banking, Fintech }