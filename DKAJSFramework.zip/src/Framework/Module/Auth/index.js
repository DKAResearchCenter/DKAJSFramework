import DKA from "./DKA";

const Auth = {
    DKA : DKA
};

export default Auth;