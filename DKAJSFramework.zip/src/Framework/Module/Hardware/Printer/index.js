import Escpos from "./Escpos";

const Printer = {
    Escpos : Escpos
};

export default Printer;
export { Escpos }