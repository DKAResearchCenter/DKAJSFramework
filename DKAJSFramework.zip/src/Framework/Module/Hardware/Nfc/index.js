import _ from "lodash";
import Options from "./../../Options";
import Security from "../../Security";

function checkModuleExist(name){
    try {
        require.resolve(name);
        return true;
    }catch (e) {
        return false;
    }
}

let Reader = null;

class Nfc {

    mNFC = null;
    eventEmit = null;

    static get KEY_TYPE_A(){
        //**********************************************************************
        return checkModuleExist("nfc-pcsc") ? require("nfc-pcsc").KEY_TYPE_A : null;
        //**********************************************************************

    }
    static get KEY_TYPE_B(){
        //**********************************************************************
        return checkModuleExist("nfc-pcsc") ? require("nfc-pcsc").KEY_TYPE_B : null;
        //**********************************************************************
    }
    /**
     *
     * @returns {Nfc}
     */
    constructor(config) {

        this.config = _.merge({
            state : Options.SERVER_STATE_DEVELOPMENT,
            cardType : Options.MIFARE_CLASSIC_1K,
            authenticate : {
                typeKey : Nfc.KEY_TYPE_A,
                key : "FFFFFFFFFFFF"
            },
            options : {
                autoProcessing : true,
                encryption : {
                    enabled : false
                }
            }
        }, config);

        let EventEmitter = require("node:events");
        this.mEventEmitter = new EventEmitter();
        if (checkModuleExist("nfc-pcsc")){
            let { NFC } = require("nfc-pcsc");
            try {
                this.mNFC = new NFC();
                this.mNFC.on('reader', async (reader) => {
                    this.mEventEmitter.emit("reader", reader);
                    (this.config.state === Options.SERVER_STATE_DEVELOPMENT) ? console.log(`reader ready ! :`,`${reader}`) : false;
                    reader.autoProcessing = this.config.options.autoProcessing;
                    await reader.on('card', async (card) => {
                        this.mEventEmitter.emit("card", { reader : reader, card : card});
                        (this.config.state === Options.SERVER_STATE_DEVELOPMENT) ? console.log(`card detected :`,`${card}`) : false;
                    })
                    reader.on('card.off', async (card) => {
                        this.mEventEmitter.emit("card.off", card);
                        (this.config.state === Options.SERVER_STATE_DEVELOPMENT) ? console.log(`card remove :`,`${card}`) : false;
                    });
                    await reader.on('error', async (error) => {
                        this.mEventEmitter.emit("card.error", { status : false, code : 502, msg : `Reader Error`, error : error});
                        (this.config.state === Options.SERVER_STATE_DEVELOPMENT) ? console.log(`reader error :`,`${error}`) : false;
                    });

                    await reader.on('end', async () => {
                        this.mEventEmitter.emit('card.end');
                        (this.config.state === Options.SERVER_STATE_DEVELOPMENT) ? console.log(`card end`) : false;
                    });
                });
                this.mNFC.on('error', async (err) => {
                    let nFCErrorExtractStatus = {
                        code : err.toString().split(":")[1].toString(),
                        description : err.toString().split(":")[2].toString(),
                    }
                    let error = { status : false, code : 500, msg : `NFC Error`, error : nFCErrorExtractStatus};
                    this.mEventEmitter.emit("nfc.error", error);
                    (this.config.state === Options.SERVER_STATE_DEVELOPMENT) ? console.log(`nfc error : `,`${nFCErrorExtractStatus}`) : false;
                });
            }catch (e) {
                let error = { status : false, code : 505, msg : `Unknown Error`, error : e }
                this.mEventEmitter.emit("nfc.fatal", error )
            }
        }else{
            throw Error("MODULE `nfc-pcsc` not Installed. Please Installed First")
        }
        return this;
    }

    /**
     *
     * @param { "UNKNOWN_ERROR" | "FATAL_ERROR" | "NFC_ERROR" | "READER_ERROR" | "READER_END" | "READER" | "CARD_DETECTED" | "CARD_OFF"  } event
     * @param {Function} callback
     * @returns {Promise<Nfc>}
     */
    Trigger = async (event, callback) => {
        switch (event) {
            case "READER":
                await this.mEventEmitter.on("reader", callback);
                break;
            case "READER_ERROR" :
                await this.mEventEmitter.on("card.error", callback);
                break;
            case "CARD_DETECTED":
                await this.mEventEmitter.on("card", callback);
                break;
            case "CARD_OFF" :
                await this.mEventEmitter.on("card.off", callback);
                break;
            case "NFC_ERROR":
                await this.mEventEmitter.on("nfc.error", callback);
                break;
            case "FATAL_ERROR" :
                await this.mEventEmitter.on("nfc.fatal", callback);
                break;
            case "UNKNOWN_ERROR" :
                await this.mEventEmitter.on("nfc.unknown.error", callback)
                break
        }
        return this;
    }


    LoadAuthentificationKey = async (keyNumber, key, response) => {
        await this.mEventEmitter.on("card", async (result) => {
            let reader = result.reader;
            await reader.loadAuthenticationKey(keyNumber, key)
                .then(async (res) => {
                    await response({ status : true, code : 200, msg : `Successfully Load Authentification Key `});
                })
                .catch(async (error) => {
                    await response({ status : false, code : 500, msg : `Failed Load Authentification Key `, error : error});
                })
        });
    }

    Authentificate = async (arraySectorCluster = [], response) => {

        await this.mEventEmitter.on("card", async (result) => {
            let reader = result.reader;

            let mArrayPass = [];
            let num = 0;
            await arraySectorCluster.forEach(function () {
                try {
                    reader.authenticate(arraySectorCluster[num].blockNumber, arraySectorCluster[num].keyType, arraySectorCluster[num].key)
                    mArrayPass.push({ status : true, blockNumber : arraySectorCluster[num].blockNumber });
                }catch (e) {
                    mArrayPass.push({ status : false, blockNumber : arraySectorCluster[num].blockNumber });
                }
                num++;
            });
            await response(mArrayPass)
        });
        return this;

    }

    /**
     *
     * @param {Number | Object} blockNumber
     * @param { Number } blockNumber.blockNumber
     * @param { 16 | 32 | 48 } blockNumber.length
     * @param { 16 } blockNumber.blockSize
     * @param { Object } blockNumber.authenticate
     * @param { KEY_TYPE_A | KEY_TYPE_B } blockNumber.authenticate.keyType
     * @param { String } blockNumber.authenticate.key
     * @param response
     * @return {Promise<Nfc>}
     * @constructor
     */
    Read = async (blockNumber, response) => {

        this.configRead = {};

        switch (typeof blockNumber){
            case "number" :
                this.configRead = await _.merge({
                    blockNumber : blockNumber,
                    dataLength : 16,
                    blockSize : 16,
                    authenticate : {
                        keyType : this.config.authenticate.typeKey,
                        key : this.config.authenticate.key
                    }
                });
                break;
            case "object" :
                this.configRead = await _.merge({
                    blockNumber : 4,
                    dataLength : 16,
                    blockSize : 16,
                    authenticate : {
                        keyType : this.config.authenticate.typeKey,
                        key : this.config.authenticate.key
                    }
                }, blockNumber);
                break;
        }

        await this.mEventEmitter.on("card", async (result) => {
            let reader = result.reader;
            try {
                await reader.authenticate(this.configRead.blockNumber, this.configRead.authenticate.keyType, this.configRead.authenticate.key);
                let mRead = await reader.read(this.configRead.blockNumber, this.configRead.length, this.configRead.blockSize);

                if (this.config.options.encryption.enabled){
                    mRead = await new Security.Encryption.Crypto({
                        algorithm : Options.ALGORITHM_AES_128_GCM
                    })
                        .decodeIvSync(mRead);
                }

                let tempRawData = mRead.toString().split("@")[0];
                let arrayTypeData = tempRawData.split("#");

                let objectTempData = {};
                arrayTypeData.map(async (values) => {
                    let jsonData = values.split(":");
                    objectTempData[jsonData[0]] = jsonData[1]
                    // jsonData.map(async (mValues) => {
                    //     console.log(mValues)
                    //     objectTempData[mValues[0]] = mValues[1]
                    // })
                });

                let mResponseTemp = {
                    status : true,
                    code : 200,
                    msg : `Successfully Read Data`,
                    data : {
                        raw : mRead,
                        string : mRead.toString().split("@")[0],
                        length : mRead.toString().length,
                        refactorData : {
                            companyId : mRead.toString().split("@")[0].split("#")[0],
                            type_card : mRead.toString().split("@")[0].split("#")[1],
                            uid_identify : mRead.toString().split("@")[0].split("#")[2],
                        },
                        card : {
                            atr : result.card.atr,
                            standard : result.card.standard,
                            type : result.card.type,
                            uid : result.card.uid
                        }
                    }
                }
                mResponseTemp.data.refactorData = objectTempData;

                await response(mResponseTemp);
            }catch (e) {
                await response({ status : false, code : 500, msg : `Failed Read Data`, error : e});
            }

        });
        return this;
    }
    Baca = this.Read;

    /**
     *
     * @param {Number | Object} data
     * @param { Number } data.blockNumber
     * @param { Object | String } data.data
     * @param { 16 | 32 | 48 } data.dataLength
     * @param { 16 } data.blockSize
     * @param { Object } data.authenticate
     * @param { KEY_TYPE_A | KEY_TYPE_B } data.authenticate.keyType
     * @param { String } data.authenticate.key
     * @param response
     * @return {Promise<Nfc>}
     * @constructor
     */
    Write = async (data, response) => {
        this.configWrite = {};
        let mFinalDataToString = "";
        switch (typeof data){
            case "string" :
                this.configWrite = await _.merge({
                    blockNumber : 4,
                    data : data,
                    dataLength : 16,
                    blockSize : 16,
                    authenticate : {
                        keyType : this.config.authenticate.typeKey,
                        key : this.config.authenticate.key
                    }
                });

                break;
            case "object" :
                this.configWrite = await _.merge({
                    blockNumber : 4,
                    data : data.data,
                    dataLength : 16,
                    blockSize : 16,
                    authenticate : {
                        keyType : this.config.authenticate.typeKey,
                        key : this.config.authenticate.key
                    }
                }, data);

                switch (typeof this.configWrite.data) {
                    case "object" :
                        //console.log(this.configWrite.data)
                        /** Add Separator Split Character (#) for The push Data **/
                        Object.keys(this.configWrite.data).map(async (key,index,array) => {
                            if (index !== (array.length - 1)){
                                mFinalDataToString += `${key}:${this.configWrite.data[key]}#`
                            }else{
                                mFinalDataToString += `${key}:${this.configWrite.data[key]}`
                            }
                        })
                        this.configWrite.data = mFinalDataToString
                        break;
                    case "string" :
                        this.configWrite.data = data.data
                        break;
                }
                break;
        }

        await this.mEventEmitter.on("card", async (result) => {
            let reader = result.reader;
            try {
                await reader.authenticate(this.configWrite.blockNumber, this.configWrite.authenticate.keyType, this.configWrite.authenticate.key)
                let mBuffer = await Buffer.allocUnsafe(this.configWrite.dataLength);
                let mFillData = `${this.configWrite.data}@`;

                if (this.config.options.encryption.enabled){
                    mFillData = new Security.Encryption.Crypto({
                        algorithm : Options.ALGORITHM_AES_128_GCM
                    })
                        .encodeIvSync(mFillData)
                }

                await mBuffer.fill(mFillData)
                if (this.configWrite.data.length <= this.configWrite.dataLength){
                    switch (this.config.cardType) {
                        case Options.MIFARE_CLASSIC_1K :
                            if (this.configWrite.blockNumber === 4 || this.configWrite.blockNumber === 8){
                                await reader.write(this.configWrite.blockNumber, mBuffer, this.configWrite.blockSize);
                                await response({
                                    status : true,
                                    code : 200,
                                    msg : `Successfully Write Data`,
                                    data : {
                                        raw : mBuffer.toString()
                                    }
                                });
                            }else{
                                await response({
                                    status : false,
                                    code : 505,
                                    msg : `Failed Write Data. for Mifare 1 K blockNumber must 4 or 8 `
                                });
                            }
                    }

                }else{
                    await response({
                        status : false,
                        code : 505,
                        msg : `Failed Write Data. the data length must smaller than options 'dataLength' `
                    });
                }
            }catch (e) {
                await response({ status : false, code : 500, msg : `AUTHENTIFICATION : error`, error : e })
            }

        })
        return this;
    }
    Tulis = this.Write;

    Reset = async (config, response) => {
        let WriteConfig;
        WriteConfig = await _.merge({
            blockNumber : 4, blockSize: 16, authentification : {
                typeKey : this.KEY_TYPE_A,
                key : "FFFFFFFFFFFF"
            }
        }, config);
        this.mEventEmitter.on("card", async (result) => {
            let reader = result.reader;
            try {
                await reader.authenticate(
                    WriteConfig.blockNumber,
                    WriteConfig.authentification.typeKey,
                    WriteConfig.authentification.key
                )
                let mBuffer = await Buffer.allocUnsafe(WriteConfig.blockSize);
                await mBuffer.fill(0)
                await reader.write(WriteConfig.blockNumber, mBuffer, WriteConfig.blockSize);
                await response({ status : true, code : 200, msg : `Successfully Reset Data`, data : mBuffer.toString()});
                //const dataRead = await reader.read(readConfig.blockNumber, readConfig.length, readConfig.blockSize);

            }catch (e) {
                await response({ status : false, code : 505, msg : `AUTHENTIFICATION : error`, error : e })
            }
        })

        return this;
    }
    Format = this.Reset;

}


export default Nfc;