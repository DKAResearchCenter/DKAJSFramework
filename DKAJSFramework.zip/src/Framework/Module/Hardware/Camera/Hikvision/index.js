

class Hikvision {


    constructor(config) {

    }
    getImage = async () => {

    }

    getStream
}

export default Hikvision;