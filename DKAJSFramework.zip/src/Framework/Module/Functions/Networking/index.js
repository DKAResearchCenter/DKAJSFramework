import IP from "./IP";

const Networking = {
    IP : IP
};

export default Networking;
export { IP };