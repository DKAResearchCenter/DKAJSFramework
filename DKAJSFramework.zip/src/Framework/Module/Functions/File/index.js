import ftp from "./ftp";


const File = {
    Ftp : ftp
}


export { File };
export default File;