'use strict';
'use warning';

import _ from 'lodash';

/**
 * 
 */
class Cookies {
    /** Default contructor **/
    constructor(options) {
        this.options = _.extend({

        }, options);


    }


    async set(name, data) {

    }
}
export default Cookies;