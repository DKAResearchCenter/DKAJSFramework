import RSTP from "./RSTP";

const Multimedia = {
    Rstp : RSTP
};

export default Multimedia;
export {Multimedia}