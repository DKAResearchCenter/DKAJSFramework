import Responded from "./Responded";

const Extend = {
    Responded : Responded
};

export default Extend;
export {Responded};