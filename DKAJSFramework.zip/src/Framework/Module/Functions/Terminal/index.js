import childProcess from "child_process";

class Terminal {



    install = () => {
        childProcess.exec("")
    }
}