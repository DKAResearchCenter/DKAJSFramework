'use strict';
'use warning';
import _ from "lodash";

const Firewall = {
    Nat : async (config) => {
        _.extend({
            
        })
    }
}

export default Firewall;