

const Electron = async (config) => {
    const electron = require("electron/cli");


    return await new Promise(async (resolve, rejected) => {

    });
};


export default Electron;