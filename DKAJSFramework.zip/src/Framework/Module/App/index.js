import Electron from "./Electron";

const App = {
    Electron : Electron
};

export default App;