import "@tensorflow/tfjs-node";


class TensorFlow {

    constructor(config) {

    }
}


export default TensorFlow;


