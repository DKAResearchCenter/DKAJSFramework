class webrtc {

    constructor(config) {


    }




}

export default webrtc;