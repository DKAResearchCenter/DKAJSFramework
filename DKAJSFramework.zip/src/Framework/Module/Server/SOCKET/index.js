import Server from "./Server";
import Client from "./Client";

const SOCKET = {
    Server : Server,
    Client : Client
};

export default SOCKET;