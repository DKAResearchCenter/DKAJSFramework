'use strict';
'use warnings';

export default (config) => new Promise((resolve, reject) => {
    /** get fs command
     * **/
    const fs = require("fs");
    const path = require("path");

    switch (fs.existsSync(path.join())) {

    }

});