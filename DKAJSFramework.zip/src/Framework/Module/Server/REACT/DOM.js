import ReactDOM from "react-dom";
import React from "react";

ReactDOM.render(`<div><h1>Hallo2Dunia</h1></div>`, document.getElementById("dka"));