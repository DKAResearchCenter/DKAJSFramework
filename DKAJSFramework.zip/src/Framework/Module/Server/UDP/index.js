import Server from "./Server";
import Client from "./Client";

const UDP = {
    Server : Server,
    Client : Client
};
export default UDP;