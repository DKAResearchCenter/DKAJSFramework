import DKA, { Utils, Server, Functions, Hardware, Options, Config, Database } from "./../src/Framework/Module/index.module.d";
import path from "path";
import moment from "moment-timezone";

(async () => {


    let DB = new Database.MariaDB({
        host : "127.0.0.1",
        user : "developer",
        password : "Cyberhack2010",
        database : "nd_parking"
    });


    let getGroupingUser = async (tanggal) => new Promise(async (resolve, rejected) => {
        let mDateMysql = await moment(tanggal, "DD-MM-YYYY").format("YYYY-MM-DD");
        await DB.rawQuerySync(`
        SELECT
            DATE(\`out\`.\`time_created\`) as \`tanggal_transaksi\`,
            CONCAT(\`login\`.\`first_name\`, ' ', \`login\`.\`last_name\`) as \`chasier_name\`,
            \`out\`.type_transaction,
            \`out\`.type_costumer,
            COUNT(*) as \`jumlah_transaksi\`,
            SUM(\`out\`.\`hours_cost\`) as \`cost\`,
            SUM(\`out\`.\`fine_cost\`) as \`fine_cost\`,
            SUM(\`out\`.\`hours_cost\`) + SUM(\`out\`.\`fine_cost\`) as \`final_cost\`
        FROM \`parking_data_transaction_out\` as \`out\`
                 INNER JOIN \`parking_user_login\` as \`login\`
                            ON  \`out\`.\`uid_cashier\` = \`login\`.\`id_user_login\`
        WHERE DATE(\`out\`.\`time_created\`) = '${mDateMysql}'
        GROUP BY \`out\`.\`uid_cashier\`;
        `).then(async (result) => {
            resolve(result)
        }).catch(async (error) => {
            rejected(error);
        })
    });
    let getGroupingUser = async (tanggal) => new Promise(async (resolve, rejected) => {
        let mDateMysql = await moment(tanggal, "DD-MM-YYYY").format("YYYY-MM-DD");
        await DB.rawQuerySync(`
        SELECT
            DATE(\`out\`.\`time_created\`) as \`tanggal_transaksi\`,
            CONCAT(\`login\`.\`first_name\`, ' ', \`login\`.\`last_name\`) as \`chasier_name\`,
            \`out\`.type_transaction,
            \`out\`.type_costumer,
            COUNT(*) as \`jumlah_transaksi\`,
            SUM(\`out\`.\`hours_cost\`) as \`cost\`,
            SUM(\`out\`.\`fine_cost\`) as \`fine_cost\`,
            SUM(\`out\`.\`hours_cost\`) + SUM(\`out\`.\`fine_cost\`) as \`final_cost\`
        FROM \`parking_data_transaction_out\` as \`out\`
                 INNER JOIN \`parking_user_login\` as \`login\`
                            ON  \`out\`.\`uid_cashier\` = \`login\`.\`id_user_login\`
        WHERE DATE(\`out\`.\`time_created\`) = '${mDateMysql}'
        GROUP BY \`out\`.\`uid_cashier\`;
        `).then(async (result) => {
            resolve(result)
        }).catch(async (error) => {
            rejected(error);
        })
    });
    (async () => {

        getGroupingUser('11-06-2022')
            .then(async (result) => {
                result.data.map(async (json) => {

                })
            }).catch(async (rejected) => {
            console.log(rejected)
        })
    })();



    /*let NFC = await new Hardware.Nfc({
        state : Options.SERVER_STATE_DEVELOPMENT,
    });*/

    /*await NFC.Write({ data : "companyId:ND#type:GLOBAL#name:YOVANGGA ANANDHIKA", dataLength : 48 }, async (response) => {
        await console.log(response)
    });*/

    /*await NFC.Write({ data : { cId : 1, tC : "MEMBER", mId : 2 }, blockNumber : 4, dataLength : 48 }, async (response) => {
        await console.log(response)
    })*/

    /*await NFC.Write({ data : { cId : "ND", tC : "GLOBAL", nik : 4, n : "ARLAN" }, blockNumber : 4, dataLength : 48 }, async (response) => {
        console.log(response)

    });*/

    /*await NFC.Read({ blockNumber : 4, length : 48 }, async (data) => {
        console.log(data)
    });*/


    /*Utils.estimationCostFromTime({
        data : {
            hsours : 1
        }
    })*/

    /*Utils.estimationCostFromTime({
        data : {
            hours : 1
        }
    })*/




    /*let firestore = new Database.Google.Firestore();
    await firestore.collection("DKA").get()
        .then(async (querySnapshot) => {
            querySnapshot.forEach(function(doc) {
                // doc.data() is never undefined for query doc snapshots
                console.log(doc.id, " => ", doc.data());

            });
        }).catch(async (error) => {
            console.log(error)
        })*/



})();