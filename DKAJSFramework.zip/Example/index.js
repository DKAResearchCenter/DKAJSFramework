import DKA, { Utils, Server, Functions, Hardware, Options, Config, Database } from "./../src/Framework/Module/index.module.d";
import path from "path";
import moment from "moment-timezone";

(async () => {


    /*Server({
        serverEngine : Options.NTP_CORE_ENGINE,
        serverPort : 124,
        app : async (ntp) => {

        },
    })
        .then(async (result) => {
            console.log(result)
        }).catch(async (error) => {
            console.log(error)
    })*/
    let NFC = await new Hardware.Nfc({
        state : Options.SERVER_STATE_DEVELOPMENT,
    });

    NFC.Trigger("READER", async (error) => {
        console.log(error)
    })

    /*await NFC.Write({ data : "companyId:ND#type:GLOBAL#name:YOVANGGA ANANDHIKA", dataLength : 48 }, async (response) => {
        await console.log(response)
    });*/

    await NFC.Write({ data : { cId : 1, tC : "MEMBER", mId : 2, tN : 1657528186 }, blockNumber : 4, dataLength : 48 }, async (response) => {
        await console.log(response)
    })


    /*await NFC.Write({ data : { cId : "ND", tC : "GLOBAL", nik : 6, n : "MUJAHIDDIN" }, blockNumber : 4, dataLength : 48 }, async (response) => {
        console.log(response)
    });*/

    await NFC.Read({ blockNumber : 4, length : 48 }, async (data) => {
        console.log(data)
    });


    /*Utils.estimationCostFromTime({
        data : {
            hours : 1
        }
    })*/

    /*Utils.estimationCostFromTime({
        data : {
            hours : 1
        }
    })*/




    /*let firestore = new Database.Google.Firestore();
    await firestore.collection("DKA").get()
        .then(async (querySnapshot) => {
            querySnapshot.forEach(function(doc) {
                // doc.data() is never undefined for query doc snapshots
                console.log(doc.id, " => ", doc.data());

            });
        }).catch(async (error) => {
            console.log(error)
        })*/



})();